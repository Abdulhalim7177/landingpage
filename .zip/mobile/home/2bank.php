<div class="page-content header-clear-medium">
        
        <div class="card card-style">
            
            <div class="content">
                
                <p class="mb-0 text-center font-600 color-highlight">Transfer From User Wallet To Bank Account</p>
                <h1 class="text-center">Transfer From Wallet To Bank Account</h1>

                <div class="row text-center mb-2">                                                                                                   
                    
                    
                </div>
                <hr/>
                <div class="d-flex">
                    <h5 style="background:<?php echo $sitecolor; ?>; color:#ffffff; padding:9px;  margin-right:5px;">Info: </h5>
                    <marquee direction="left" scrollamount="5" style="background:#f2f2f2; padding:3px; border-radius:5rem;">
                        <h5 class="py-2">
                        Contact Admin to Transfer from your User Wallet to any Nigerian Bank Account.
                        </h5>
                    </marquee>
                </div>
                <hr/>
                
                <form method="post" class="airtimeForm" id="airtimeForm" action="buy-airtime">
                        <fieldset>
 
                            <div class="input-style input-style-always-active has-borders mb-4">
                                <label for="networktype" class="color-theme opacity-80 font-700 font-12">Select Receiver Bank</label>
                                <select id"Receiver Bank" name="Receiver Bank">
                        <option value="Access Bank" style="color:#000000 !important;">Access Bank</option>
                              <option value="9PSB" style="color:#000000 !important;">9PSB</option>
                              <option value="AB Microfinance Bank" style="color:#000000 !important;">AB Microfinance Bank</option>
                              <option value="Abbey Mortgage Bank" style="color:#000000 !important;">Abbey Mortgage Bank</option>
                              <option value="Accion MFB" style="color:#000000 !important;">Accion MFB</option>
                              <option value="Branch" style="color:#000000 !important;">Branch</option>
                              <option value="Dot Microfinance Bank" style="color:#000000 !important;">Dot Microfinance Bank</option>
                              <option value=" FairMoney MFB" style="color:#000000 !important;">FairMoney MFB</option>
                              <option value="Fairmoney MFB" style="color:#000000 !important;">FinaTrust MFB</option>
                              <option value="FinaaTrust MFB" style="color:#000000 !important;">Diamond Bank</option>
                              <option value="Enterprise Bank" style="color:#000000 !important;">Enterprise Bank</option>
                              <option value="Eco Bank" style="color:#000000 !important;">Eco Bank</option>
                              <option value="FCMB" style="color:#000000 !important;">FCMB</option>
                              <option value="First Bank" style="color:#000000 !important;">First Bank</option>
                              <option value="Fidelity Bank" style="color:#000000 !important;">Fidelity Bank</option>
                              <option value="Gt Bank" style="color:#000000 !important;">Gt Bank</option>
                              <option value="Heritage Banking" style="color:#000000 !important;">Heritage Banking</option>to
                              <option value="Jaiz Bank" style="color:#000000 !important;">Jaiz Bank</option>
                              <option value="Kuda Bank" style="color:#000000 !important;">Kuda Bank</option>
                              <option value="Lotus Bank" style="color:#000000 !important;">Lotus Bank</option>
                              <option value="Momo Payment Service Bank" style="color:#000000 !important;">Momo Payment Service Bank</option>
                              <option value="Keystone Bank" style="color:#000000 !important;">Keystone Bank</option>
                              <option value="NowNow" style="color:#000000 !important;">NowNow</option>
                              <option value="Paga" style="color:#000000 !important;">Paga</option>
                              <option value="Providus Bank" style="color:#000000 !important;">Providus Bank</option>
                              <option value="Moniepoint" style="color:#000000 !important;">Moniepoint</option>
                              <option value="Rubies MFB" style="color:#000000 !important;">Rubies MFB</option>
                              <option value="Opay(Paycom)" style="color:#000000 !important;">Opay(Paycom)</option>
                              <option value="Sparkle" style="color:#000000 !important;">Sparkle</option>
                              <option value="Standard Chatered Bank" style="color:#000000 !important;">Standard Chatered Bank</option>
                              <option value="Polaris Bank" style="color:#000000 !important;">Polaris Bank</option>
                              <option value="Sterling Bank" style="color:#000000 !important;">Sterling Bank</option>
                              <option value="VFD Microfinance" style="color:#000000 !important;">VFD Microfinance</option>
                              <option value="Union Bank" style="color:#000000 !important;">Union Bank</option>
                              <option value="UBA" style="color:#000000 !important;">UBA</option>
                              <option value="Wema Bank" style="color:#000000 !important;">Wema Bank</option>
                              <option value="Zenith Bank Plc" style="color:#000000 !important;">Zenith Bank Plc</option>
                        </select>
                                </select>
                                <span><i class="fa fa-chevron-down"></i></span>
                                <i class="fa fa-check disabled valid color-green-dark"></i>
                                <i class="fa fa-check disabled invalid color-red-dark"></i>
                                <em></em>
                            </div>


 
                  <div class="input-style input-style-always-active has-borders validate-field mb-4">
                                <label for="businessname" class="color-theme opacity-80 font-700 font-12">Bank Account Holder Name</label>
                                <input type="text" name="businessname" placeholder="Bank Account Holder Name" value="" class="round-small" id="bankaccountholdername"  required  />
                            </div>
          

                            
                            <div class="input-style input-style-always-active has-borders validate-field mb-4">
                                <label for="phone" class="color-theme opacity-80 font-700 font-12">Amount</label>
                                <input type="number" name="Amount" placeholder="Enter Amount" value="" class="round-small" id="phone" required  />
                            </div>

                            <input name="transref" type="hidden" value="<?php echo $transRef; ?>" />
                            <input name="transkey" id="transkey" type="hidden" />

                            
                            <div class="row pt-3 mb-3">
                        <div class="col-12 text-center font-15 mt-2">
                            <a class="text-dark" href="https://wa.me/7026417709"<b>CLICK TO TRANSFER TO BANK</b></a>
                        </div>
                    </form>        
            </div>

        </div>

</div>



