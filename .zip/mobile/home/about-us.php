<div class="page-content header-clear-medium">
        
        <div class="card card-style">
            <div class="content">
                <p class="mb-0 font-600 color-highlight">Goocredit </p>
                <h1>About Us</h1>
                <p class="text-black">
                GooCredit is your onestop platform for all your bills payment. We provide you an easy way to topup your Airtime, <br>
                Internet Data, Cable TV Subscription, and Electricity Subscription. All our services are provided to you at the <br>
                best and cheapest rate possible to fund your lifestyle. 
                <br/><br/>
                Everyone loves an easy to use platform with no delay, that is why we are fully automated, the best partner you can <br>
                trust. Our customer support team is always available to you 24/7.<br>
                <b>//////Log Version Update//////</b><br>
                -- v4.9 - 2022<br>
                -- v5.0 - 2023<br>
                -- v5.8 - 2024 <br>
                -- v5.9 - 24/05/2024 <br>
                -- v6.0 - 01/06/2024 <br>
                -- v6.5 - <b>Oct/2024</b> <br>
                 -- v6.6 - <b>Oct/2024</b> <br>
                 -- v6.8 - December/2024 <br>
                </p> 
                
                <p>
                    <img src="/assets/GC-Preview-6.5.png" class="img-fluid" />
                </p>
            </div>
        </div>


</div>