<div class="alert alert-danger text-center">You Don't Have Kuda Api Contact<a href="https://wa.me/2348032230464"> Betadata To Integrate It In Your Website</a> Licensed Software, All Right Reserved</div>

<div class="row">
        <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="text-center">
                    <h2 class="fa fa-whatsapp text-info font-size-50"></h2>
                    <h2 class="mb-2 mt-2">Whatsapp</h2>
                    <a class="btn btn-info btn-block" href="https://wa.me/2348032230464"> 
                        Join <i class="fa fa-forward" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

<div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="text-center">
                    <h2 class="fa fa-globe text-info font-size-50"></h2>
                    <h2 class="mb-2 mt-2">Website</h2>
                    <a class="btn btn-info  btn-block" href="https://betadata.com.ng/links"> 
                        Join <i class="fa fa-forward" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    
</div>