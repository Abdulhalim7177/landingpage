<!-- Content Wrapper. Contains page content 
    <div class="content-wrapper">

      <!--Page Title -->
      <!--<section class="content-header">
        <h1>Payment Gateway</h1>        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#"><i class="ti-dashboard"></i></a></li>
          <li class="breadcrumb-item active">Payment Gateway</li>
        </ol>
      </section>-->
<!-- Main content 
      <section class="content">-->

                <div class="row">
    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="d-flex  align-items-center">
                    <h2 class="fa fa-code text-white font-size-20 bg-info" style="border-radius:50px; text-align:center;  padding:10px; width:50px; height:auto;"></h2>
                    <h2 class="mb-2 mt-2 pl-5 ml-5">
                        <a class="" href="./monnify-setting">
                            <b>Monnify</b>
                        </a>
                    </h2>

                </div>
            </div>
        </div>
    </div>


    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="d-flex  align-items-center">
                    <h2 class="fa fa-code text-white font-size-20 bg-info" style="border-radius:50px; text-align:center;  padding:10px; width:50px; height:auto;"></h2>
                    <h2 class="mb-2 mt-2 pl-5 ml-5">
                        <a class="" href="./paystack-setting">
                            <b>Paystack</b>
                        </a>
                    </h2>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="d-flex  align-items-center">
                    <h2 class="fa fa-code text-white font-size-20 bg-info" style="border-radius:50px; text-align:center;  padding:10px; width:50px; height:auto;"></h2>
                    <h2 class="mb-2 mt-2 pl-5 ml-5">
                        <a class="" href="./payvessel-settings">
                            <b>Payvessel</b>
                        </a>
                    </h2>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="d-flex  align-items-center">
                    <h2 class="fa fa-code text-white font-size-20 bg-info" style="border-radius:50px; text-align:center;  padding:10px; width:50px; height:auto;"></h2>
                    <h2 class="mb-2 mt-2 pl-5 ml-5">
                        <a class="" href="./kuda-setting">
                            <b>Kuda Api</b>
                        </a>
                    </h2>

                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="d-flex  align-items-center">
                    <h2 class="fa fa-code text-white font-size-20 bg-info" style="border-radius:50px; text-align:center;  padding:10px; width:50px; height:auto;"></h2>
                    <h2 class="mb-2 mt-2 pl-5 ml-5">
                        <a class="" href="./aspfiy-setting">
                            <b>Aspfiy</b>
                        </a>
                    </h2>

                </div>
            </div>
        </div>
    </div>


    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="d-flex  align-items-center">
                    <h2 class="fa fa-code text-white font-size-20 bg-info" style="border-radius:50px; text-align:center;  padding:10px; width:50px; height:auto;"></h2>
                    <h2 class="mb-2 mt-2 pl-5 ml-5">
                        <a class="" href="./vpay-setting">
                            <b>Vpay</b>
                        </a>
                    </h2>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="d-flex  align-items-center">
                    <h2 class="fa fa-code text-white font-size-20 bg-info" style="border-radius:50px; text-align:center;  padding:10px; width:50px; height:auto;"></h2>
                    <h2 class="mb-2 mt-2 pl-5 ml-5">
                        <a class="" href="./billstack-setting">
                            <b>Billstack</b>
                        </a>
                    </h2>
                </div>
            </div>
        </div>
    </div>