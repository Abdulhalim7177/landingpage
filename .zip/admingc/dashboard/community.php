<div class="alert alert-danger text-center">Betadata is A Product Of <a href="https://wa.me/2348032230464">MultiComs</a> | All Right Reserved</div>

<div class="row">

    <div class="col-md-12">
        <div class="box" style="background:url('../../assets/img/community.png')">
            <div class="box-body text-center" style="background:rgba(255,255,255,0.9);">
               
                    <h1 class="fa fa-users font-size-40 bg-info text-white" style="padding:20px; border-radius:50%"></h1>
                    <h1 class="mb-2 mt-2 text-info"><b>Hi There!</b></h1>
                    <h3 class="mb-2 mt-2 text-primary"><b>Let Me Introduce You To Betadata</b></h3>
                    <p class="mb-2 mt-2">
                        <b>Its time to make more money with Betadata, But With The Help Of A Community, Its Only Gets Easier.</b>
                    </p>

                    <p class="mb-2 mt-2">
                        <b>Instant Recharge on Betadata that allows you to Buy Cheap Mobile Data, <br> Airtime, Pay Electricity Bill, Pay TV Subscription, Educational Payment, Print Recharge Card & Data Pin.</b>
                    </p>

                    <p class="mb-2 mt-2">
                        <b>Get All The Latest Update about the next version development. </b>
                    </p>

                    <h3 class="mb-2 mt-2 text-primary"><b>Sounds Good Right?<br/> Join Our Community Today</b></h3>
                    
                    
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="text-center">
                    <h2 class="fa fa-globe text-info font-size-50"></h2>
                    <h2 class="mb-2 mt-2">Cheap Api</h2>
                    <a class="btn btn-info  btn-block" href="https://Betadata.com.ng"> 
                        Join <i class="fa fa-forward" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

   

    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="text-center">
                    <h2 class="fa fa-list-alt text-info font-size-50"></h2>
                    <h2 class="mb-2 mt-2">Channel</h2>
                    <a class="btn btn-info  btn-block" href="https://wa.me/2348032230464"> 
                        Join <i class="fa fa-forward" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="text-center">
                    <h2 class="fa fa-whatsapp text-info font-size-50"></h2>
                    <h2 class="mb-2 mt-2">Whatsapp</h2>
                    <a class="btn btn-info btn-block" href="https://wa.me/2348032230464"> 
                        Join <i class="fa fa-forward" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    
</div>