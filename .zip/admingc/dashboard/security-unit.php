<div class="row">


    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="d-flex  align-items-center">
                    <h2 class="fa fa-users text-white font-size-20 bg-info" style="border-radius:50px; text-align:center;  padding:10px; width:50px; height:auto;"></h2>
                    <h2 class="mb-2 mt-2 pl-5 ml-5">
                        <a class="" href="./blacklist-setting"> 
                            <b>Black List</b>
                        </a>
                    </h2>
                    
                </div>
            </div>
        </div>
    </div>