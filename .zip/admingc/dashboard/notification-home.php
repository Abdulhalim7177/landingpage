<div class="row">


    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="d-flex  align-items-center">
                    <h2 class="fa fa-info text-white font-size-20 bg-info" style="border-radius:50px; text-align:center;  padding:10px; width:50px; height:auto;"></h2>
                    <h2 class="mb-2 mt-2 pl-5 ml-5">
                        <a class="" href="<?php echo $urlAddon; ?>notifications"> 
                            <b>Site Notification</b>
                        </a>
                    </h2>
                    
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="d-flex  align-items-center">
                    <h2 class="fa fa-envelope text-white font-size-20 bg-info" style="border-radius:50px; text-align:center;  padding:10px; width:50px; height:auto;"></h2>
                    <h2 class="mb-2 mt-2 pl-5 ml-5">
                        <a class="" href="<?php echo $urlAddon; ?>send-email"> 
                            <b>Send Mail</b>
                        </a>
                    </h2>
                    
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="box">
            <div class="box-body">
                <div class="d-flex  align-items-center">
                    <h2 class="fa fa-wechat text-white font-size-20 bg-info" style="border-radius:50px; text-align:center;  padding:10px; width:50px; height:auto;"></h2>
                    <h2 class="mb-2 mt-2 pl-5 ml-5">
                        <a class="" href="<?php echo $urlAddon; ?>messages"> 
                            <b>Site Message</b>
                        </a>
                    </h2>
                    
                </div>
            </div>
        </div>
    </div>

    
   

</div>
