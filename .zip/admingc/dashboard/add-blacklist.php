<div class="row">
<div class="col-12">
<div class="card recent-sales overflow-auto">
        <div class="card-body">
         <h5 class="card-title">Blacklisted Numbers</h5>
         <form method="POST">
         <input type="text" name="phone" value="" class="form-control" required>
         <button type="submit" name="blacklist-number" class="btn btn-primary mt-3"><b>Add Number</b></button></form>
        </div>