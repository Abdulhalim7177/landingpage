<footer class="main-footer text-center">
    <b>&copy; <?php echo date("Y"); ?> developed by| <a href="https://betadata.com.ng/links/">Betadata tech ltd</a></b>
</footer>