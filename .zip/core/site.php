<?php
// Configuration Settings
$sitename = "Afaf Datasub";
$parentdirectory = "/";

// Use the corresponding secret and public keys
$secret_key = "f63102b7268fe526da1bceb3baf18f20";  // Your secret key
$public_key = md5(base64_encode('specialsubdata.ng'));   // License for specialsubdata.ng
?>